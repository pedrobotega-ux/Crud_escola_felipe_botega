from flask import Flask, render_template, request, redirect
import psycopg2
app = Flask(__name__)

def ligar_banco():
    banco = psycopg2.connect(
        database="escola",
        user="postgres",
        password="senai",
        host="localhost",
        port="5432"
    )
    return banco

@app.route("/")
def inicio():
    return render_template("index.html")

@app.route("/disciplinas")
def disciplinas():
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute("SELECT * FROM disciplina")
    lista = cursor.fetchall()
    cursor.close()
    banco.close()
    return render_template("disciplina.html", lista=lista)

@app.route("/disciplinas/enviar", methods=["POST"])
def enviar_disciplina():
    nome = request.form.get("nome")
    professor = request.form.get("professor")
    carga_horaria = request.form.get("carga_horaria")
    data_inicio = request.form.get("data_inicio")
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        """INSERT INTO disciplina
        (nome, professor, carga_horaria, data_inicio)
        VALUES (%s, %s, %s, %s)""",
        (nome, professor, carga_horaria, data_inicio)
    )
    banco.commit()
    cursor.close()
    banco.close()
    return redirect("/disciplinas")

@app.route("/disciplinas/editar/<int:id>")
def editar_disciplina(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        "SELECT * FROM disciplina WHERE id = %s",
        (id,)
    )
    disciplina = cursor.fetchone()
    cursor.close()
    banco.close()

    return render_template(
        "editar_disciplina.html",
        disciplina=disciplina
    )

@app.route("/disciplinas/atualizar/<int:id>", methods=["POST"])
def atualizar_disciplina(id):
    nome = request.form.get("nome")
    professor = request.form.get("professor")
    carga_horaria = request.form.get("carga_horaria")
    data_inicio = request.form.get("data_inicio")
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        """UPDATE disciplina
        SET nome = %s, professor = %s,
        carga_horaria = %s, data_inicio = %s
        WHERE id = %s""",
        (nome, professor, carga_horaria, data_inicio, id)
    )
    banco.commit()
    cursor.close()
    banco.close()
    return redirect("/disciplinas")

@app.route("/disciplinas/excluir/<int:id>", methods=["POST"])
def excluir_disciplina(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        "DELETE FROM disciplina WHERE id = %s",
        (id,)
    )
    banco.commit()
    cursor.close()
    banco.close()
    return redirect("/disciplinas")

@app.route("/turmas")
def turmas():
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute("SELECT * FROM turma")
    lista = cursor.fetchall()
    cursor.close()
    banco.close()
    return render_template("turma.html", lista=lista)

@app.route("/turmas/enviar", methods=["POST"])
def enviar_turma():
    nome = request.form.get("nome")
    turno = request.form.get("turno")
    vagas = request.form.get("vagas")
    mensalidade = request.form.get("mensalidade")
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        """INSERT INTO turma
        (nome, turno, vagas, mensalidade)
        VALUES (%s, %s, %s, %s)""",
        (nome, turno, vagas, mensalidade)
    )
    banco.commit()
    cursor.close()
    banco.close()
    return redirect("/turmas")

@app.route("/turmas/editar/<int:id>")
def editar_turma(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        "SELECT * FROM turma WHERE id = %s",
        (id,)
    )
    turma = cursor.fetchone()
    cursor.close()
    banco.close()
    return render_template(
        "editar_turma.html",
        turma=turma
    )

@app.route("/turmas/atualizar/<int:id>", methods=["POST"])
def atualizar_turma(id):
    nome = request.form.get("nome")
    turno = request.form.get("turno")
    vagas = request.form.get("vagas")
    mensalidade = request.form.get("mensalidade")
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        """UPDATE turma
        SET nome = %s, turno = %s,
        vagas = %s, mensalidade = %s
        WHERE id = %s""",
        (nome, turno, vagas, mensalidade, id)
    )
    banco.commit()
    cursor.close()
    banco.close()
    return redirect("/turmas")

@app.route("/turmas/excluir/<int:id>", methods=["POST"])
def excluir_turma(id):
    banco = ligar_banco()
    cursor = banco.cursor()
    cursor.execute(
        "DELETE FROM turma WHERE id = %s",
        (id,)
    )
    banco.commit()
    cursor.close()
    banco.close()
    return redirect("/turmas")

if __name__ == "__main__":
    app.run()
